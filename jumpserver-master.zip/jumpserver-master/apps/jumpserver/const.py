# -*- coding: utf-8 -*-
#
VERSION = '1.5.2'
