#!/usr/bin/with-contenv sh

cp -rn /app/guacamole /config
